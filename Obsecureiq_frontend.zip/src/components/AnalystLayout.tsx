import { ReactNode } from "react";
import { useLocation, Link } from "react-router-dom";
import { Users, FileText } from "lucide-react";
import { cn } from "@/lib/utils";
import TopNavBar from "./TopNavBar";

interface AnalystLayoutProps {
  children: ReactNode;
}

const AnalystLayout = ({ children }: AnalystLayoutProps) => {
  const location = useLocation();

  const navItems = [
    { name: "Clients", path: "/analyst/dashboard", icon: Users },
    { name: "Generated Documents", path: "/analyst/generated-documents", icon: FileText },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <TopNavBar />

      <aside className="fixed left-0 top-16 h-[calc(100vh-4rem)] w-64 bg-gradient-to-b from-accent/10 via-background to-primary/10 backdrop-blur-sm border-r border-accent/30 shadow-medium z-40">
        <nav className="p-4 space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link key={item.path} to={item.path}>
                <div
                  className={cn(
                    "w-full rounded-lg px-4 py-3 flex items-center text-sm font-medium cursor-pointer transition-all duration-200",
                    active 
                      ? "bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 text-white shadow-soft" 
                      : "text-foreground hover:bg-gradient-to-r hover:from-accent/20 hover:to-primary/20 hover:scale-[1.02]"
                  )}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </div>
              </Link>
            );
          })}
        </nav>
      </aside>

      <main className="pt-16 ml-64">
        <div className="p-8">{children}</div>
      </main>
    </div>
  );
};

export default AnalystLayout;
