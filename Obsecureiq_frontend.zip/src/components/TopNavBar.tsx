import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { KeyRound, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import ChangePasswordModal from "@/components/modals/ChangePasswordModal";
import { useToast } from "@/hooks/use-toast";
import { useApi } from "@/hooks/use-api";
import { BASE_URL } from "@/constants/api";

const TopNavBar = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const { toast } = useToast();

  const handleLogoClick = () => {
    console.log("User role:", user?.role);
    
    if (user?.role === "analyst") {
      console.log("Navigating to analyst dashboard");
      navigate("/analyst/dashboard");
    } else if (user?.role === "admin") {
      console.log("Navigating to admin dashboard");
      navigate("/admin/dashboard");
    } else {
      console.log("Unknown role, redirecting to login");
      navigate("/login");
    }
  };

  const getInitials = () => {
    if (!user) return "U";
    return user.name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const { apiCall } = useApi();

  const handleChangePassword = async (oldPassword: string, newPassword: string) => {
    try {
      const response = await apiCall(`${BASE_URL}/change-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          old_password: oldPassword,
          new_password: newPassword,
        }),
      });

      if (response.ok) {
        setIsChangePasswordOpen(false);
        toast({
          title: "Success",
          description: "Password changed successfully.",
        });
      } else {
        const errorData = await response.json();
        toast({
          title: "Error",
          description: errorData.detail || "Failed to change password.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while changing password.",
        variant: "destructive",
      });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 border-b border-white/20 shadow-medium z-50 backdrop-blur-sm">
      <div className="flex items-center justify-between h-full px-6">
        {/* Left side - Logo */}
        <button
          onClick={handleLogoClick}
          className="flex items-center gap-3 cursor-pointer group transition-all duration-300 hover:scale-105"
        >
          <div className="w-10 h-10 rounded-xl bg-white/90 flex items-center justify-center group-hover:scale-110 transition-all">
            <span className="text-xl">🔍</span>
          </div>
          <span className="text-xl text-white font-bold tracking-wide drop-shadow-md">
            ObscureIQ
          </span>
        </button>

        {/* Right side - Profile and Logout */}
        <div className="flex items-center gap-3">
          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="relative h-11 w-11 rounded-full bg-white/90 text-primary font-semibold transition-all hover:scale-105 hover:bg-white"
              >
                <Avatar>
                  <AvatarFallback className="bg-transparent text-primary font-semibold">
                    {getInitials()}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-popover shadow-strong z-50" align="end">
              <DropdownMenuItem onClick={() => setIsChangePasswordOpen(true)} className="cursor-pointer py-2.5 hover:bg-gradient-to-r hover:from-accent/20 hover:to-primary/20 focus:bg-gradient-to-r focus:from-accent/20 focus:to-primary/20">
                <KeyRound className="mr-2 h-4 w-4" />
                Change Password
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="cursor-pointer py-2.5 text-destructive hover:bg-destructive/10 focus:bg-destructive/10">
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Logout Button */}
          <Button
            onClick={logout}
            className="rounded-lg px-5 py-2.5 bg-white/90 text-primary hover:scale-105 transition-all font-semibold hover:bg-white"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>

      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
        onChangePassword={handleChangePassword}
      />
    </header>
  );
};

export default TopNavBar;
