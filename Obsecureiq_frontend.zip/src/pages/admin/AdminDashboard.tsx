import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Download } from "lucide-react";
import AdminLayout from "@/components/AdminLayout";
import { Badge } from "@/components/ui/badge";
import { BASE_URL } from "@/constants/api";
import { useApi } from "@/hooks/use-api";

interface User {
  id: number;
  full_name: string;
  email: string;
  role: string;
  status: string;
  created_at: string;
}

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { apiCall } = useApi();
  const [recentUsers, setRecentUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentUsers();
    fetchRecentClients();
  }, []);

  const fetchRecentUsers = async () => {
    try {
      const response = await apiCall(`${BASE_URL}/users`);
      
      if (response.ok) {
        const data = await response.json();
        const lastThreeUsers = data.slice(-3).reverse();
        setRecentUsers(lastThreeUsers);
      }
    } catch (error) {
      console.error("Error fetching recent users:", error);
    } finally {
      setLoading(false);
    }
  };

  const [recentClients, setRecentClients] = useState([]);
  const [clientsLoading, setClientsLoading] = useState(true);

  const fetchRecentClients = async () => {
    try {
      const response = await apiCall(`${BASE_URL}/clients`);
      
      if (response.ok) {
        const data = await response.json();
        const lastThreeClients = data.slice(-3).reverse();
        setRecentClients(lastThreeClients);
      }
    } catch (error) {
      console.error("Error fetching recent clients:", error);
    } finally {
      setClientsLoading(false);
    }
  };

  const recentDocuments = [
    { id: 2, name: "Client Proposal - ACME Corp", type: "DOCX", date: "2024-03-14" },
    { id: 6, name: "Service Agreement", type: "DOCX", date: "2024-03-10" },
    { id: 9, name: "Legal Contract - XYZ Ltd", type: "DOCX", date: "2024-03-07" },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8 animate-fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground text-base">Welcome back! Here's an overview of your workspace.</p>
        </div>

        {/* Clients Section */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Recent Clients</h2>
            <Button className="bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 text-white hover:scale-105 transition-all" onClick={() => navigate("/admin/clients")}>
              View All
            </Button>
          </div>
          <div className="bg-card rounded-xl shadow-medium border border-border/50 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone Number</TableHead>
                  <TableHead>Date of Birth</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clientsLoading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      Loading recent clients...
                    </TableCell>
                  </TableRow>
                ) : recentClients.length > 0 ? (
                  recentClients.map((client) => (
                    <TableRow key={client.ID}>
                      <TableCell className="font-medium">{client.full_name}</TableCell>
                      <TableCell>{client.email}</TableCell>
                      <TableCell>{client.phone_number}</TableCell>
                      <TableCell>{client.date_of_birth ? new Date(client.date_of_birth).toLocaleDateString() : 'N/A'}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      No recent clients found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Manage Users Section */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Recent Users</h2>
            <Button className="bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 text-white hover:scale-105 transition-all" onClick={() => navigate("/admin/manage-users")}>
              View All
            </Button>
          </div>
          <div className="bg-card rounded-xl shadow-medium border border-border/50 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      Loading recent users...
                    </TableCell>
                  </TableRow>
                ) : recentUsers.length > 0 ? (
                  recentUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.full_name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.role}</TableCell>
                      <TableCell>
                        <Badge variant={user.status === "Active" ? "default" : "secondary"}>
                          {user.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8">
                      No recent users found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </div>

        {/* Generated Documents Section */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-semibold">Recent Documents (DOCX)</h2>
            <Button className="bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 text-white hover:scale-105 transition-all" onClick={() => navigate("/admin/generated-documents")}>
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {recentDocuments.map((doc) => (
              <div
                key={doc.id}
                className="bg-card rounded-xl shadow-medium border border-border/50 p-5 flex items-center justify-between transition-all hover:shadow-hover hover:scale-[1.01]"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 flex items-center justify-center flex-shrink-0">
                    <FileText className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{doc.name}</h3>
                    <p className="text-sm text-muted-foreground">{new Date(doc.date).toLocaleDateString()}</p>
                  </div>
                </div>
                <Button className="bg-gradient-to-r from-accent/90 via-accent/85 to-primary/60 text-white hover:scale-105 transition-all">
                  <Download className="mr-2 h-4 w-4" />
                  Download
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
